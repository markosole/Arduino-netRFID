#
# TABLE STRUCTURE FOR: articles
#

DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `articles` (`id`, `title`, `slug`, `author_id`, `content`, `date_added`, `published`) VALUES ('1', 'CM Bodovi', 'Neki slug', '1', 'tekst ide ovdje..', '2016-02-20 13:10:42', 'yes');


#
# TABLE STRUCTURE FOR: authors
#

DROP TABLE IF EXISTS `authors`;

CREATE TABLE `authors` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bio` text COLLATE utf8_unicode_ci NOT NULL,
  `avatar_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `authors` (`id`, `name`, `email`, `bio`, `avatar_image`, `published`) VALUES ('1', 'Prvi autor', 'marko@reflect.ba', '', '', 'yes');


#
# TABLE STRUCTURE FOR: fuel_archives
#

DROP TABLE IF EXISTS `fuel_archives`;

CREATE TABLE `fuel_archives` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ref_id` int(10) unsigned NOT NULL,
  `table_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `version` smallint(5) unsigned NOT NULL,
  `version_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `archived_user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('1', '1', 'fuel_pages', '{\"id\":1,\"location\":\"kartice\\/korisnici\",\"layout\":\"main\",\"published\":\"yes\",\"cache\":\"yes\",\"date_added\":\"2016-02-13 13:04:33\",\"last_modified\":\"2016-02-13 13:04:33\",\"last_modified_by\":\"\",\"variables\":[{\"id\":\"1\",\"page_id\":\"1\",\"name\":\"page_title\",\"scope\":\"\",\"value\":\"Korisnici\",\"type\":\"string\",\"language\":\"english\",\"active\":\"yes\",\"layout\":\"main\",\"location\":\"kartice\\/korisnici\",\"page_published\":\"yes\"},{\"id\":\"2\",\"page_id\":\"1\",\"name\":\"meta_description\",\"scope\":\"\",\"value\":\"\",\"type\":\"string\",\"language\":\"english\",\"active\":\"yes\",\"layout\":\"main\",\"location\":\"kartice\\/korisnici\",\"page_published\":\"yes\"},{\"id\":\"3\",\"page_id\":\"1\",\"name\":\"meta_keywords\",\"scope\":\"\",\"value\":\"\",\"type\":\"string\",\"language\":\"english\",\"active\":\"yes\",\"layout\":\"main\",\"location\":\"kartice\\/korisnici\",\"page_published\":\"yes\"},{\"id\":\"4\",\"page_id\":\"1\",\"name\":\"heading\",\"scope\":\"\",\"value\":\"Uvod...\",\"type\":\"string\",\"language\":\"english\",\"active\":\"yes\",\"layout\":\"main\",\"location\":\"kartice\\/korisnici\",\"page_published\":\"yes\"},{\"id\":\"5\",\"page_id\":\"1\",\"name\":\"body\",\"scope\":\"\",\"value\":\"Ostatak teksta\",\"type\":\"string\",\"language\":\"english\",\"active\":\"yes\",\"layout\":\"main\",\"location\":\"kartice\\/korisnici\",\"page_published\":\"yes\"},{\"id\":\"6\",\"page_id\":\"1\",\"name\":\"body_class\",\"scope\":\"\",\"value\":\"\",\"type\":\"string\",\"language\":\"english\",\"active\":\"yes\",\"layout\":\"main\",\"location\":\"kartice\\/korisnici\",\"page_published\":\"yes\"}]}', '1', '2016-02-13 16:04:33', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('2', '1', 'fuel_blocks', '{\"id\":1,\"name\":\"Toni Galic USA\",\"description\":\"\",\"view\":\"\",\"language\":\"english\",\"published\":\"yes\",\"date_added\":\"2016-02-20 11:22:50\",\"last_modified\":\"2016-02-20 11:22:50\"}', '1', '2016-02-20 14:22:50', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('3', '1', 'authors', '{\"id\":1,\"name\":\"Prvi autor\",\"email\":\"marko@reflect.ba\",\"bio\":\"\",\"avatar_image\":\"\",\"published\":\"yes\"}', '1', '2016-02-20 15:39:24', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('4', '1', 'articles', '{\"id\":1,\"title\":\"CM Bodovi\",\"slug\":\"Neki slug\",\"author_id\":\"1\",\"content\":\"tekst ide ovdje..\",\"date_added\":\"2016-02-20 13:10:42\",\"published\":\"yes\"}', '1', '2016-02-20 16:10:42', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('8', '1', 'rfid_tags', '{\"id\":\"1\",\"name\":\"Prva kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"A93280\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Opis gdje se nalazi kartica...\",\"enabled\":\"yes\"}', '4', '2016-02-20 16:34:35', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('9', '2', 'rfid_tags', '{\"id\":2,\"name\":\"Prva kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"454C1B0\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Vlasnik druge kartice..\",\"enabled\":\"yes\"}', '1', '2016-02-20 16:35:32', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('10', '2', 'rfid_tags', '{\"id\":\"2\",\"name\":\"Druga kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"454C1B0\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Vlasnik druge kartice..\",\"enabled\":\"yes\"}', '2', '2016-02-20 16:38:19', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('11', '1', 'rfid_tags', '{\"id\":\"1\",\"name\":\"Prva kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"A93280\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Opis gdje se nalazi kartica...\",\"enabled\":\"no\"}', '5', '2016-02-20 16:45:33', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('12', '1', 'rfid_tags', '{\"id\":\"1\",\"name\":\"Prva kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"A93280\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Opis gdje se nalazi kartica...\",\"enabled\":\"yes\"}', '6', '2016-02-20 16:48:27', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('13', '1', 'rfid_tags', '{\"id\":\"1\",\"name\":\"Prva kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"A93280\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Opis gdje se nalazi kartica...\",\"enabled\":\"no\"}', '7', '2016-02-20 16:48:44', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('14', '2', 'rfid_tags', '{\"id\":\"2\",\"name\":\"Druga kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"454C1B0\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Vlasnik druge kartice..\",\"enabled\":\"no\"}', '3', '2016-02-20 16:48:51', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('15', '1', 'rfid_tags', '{\"id\":\"1\",\"name\":\"Prva kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"A93280\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Opis gdje se nalazi kartica...\",\"enabled\":\"yes\"}', '8', '2016-02-20 16:51:01', '1');
INSERT INTO `fuel_archives` (`id`, `ref_id`, `table_name`, `data`, `version`, `version_timestamp`, `archived_user_id`) VALUES ('16', '2', 'rfid_tags', '{\"id\":\"2\",\"name\":\"Druga kartica\",\"dev_id\":\"DFTK35\",\"tag\":\"454C1B0\",\"mac\":\"0F:0F:0F:0D\",\"description\":\"Vlasnik druge kartice..\",\"enabled\":\"yes\"}', '4', '2016-02-20 16:51:09', '1');


#
# TABLE STRUCTURE FOR: fuel_blocks
#

DROP TABLE IF EXISTS `fuel_blocks`;

CREATE TABLE `fuel_blocks` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `view` text COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'english',
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  `date_added` datetime DEFAULT NULL,
  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`language`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_blocks` (`id`, `name`, `description`, `view`, `language`, `published`, `date_added`, `last_modified`) VALUES ('1', 'Toni Galic USA', '', '', 'english', 'yes', '2016-02-20 11:22:50', '2016-02-20 11:22:50');


#
# TABLE STRUCTURE FOR: fuel_categories
#

DROP TABLE IF EXISTS `fuel_categories`;

CREATE TABLE `fuel_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `context` varchar(100) NOT NULL DEFAULT '',
  `language` varchar(30) NOT NULL DEFAULT 'english',
  `precedence` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `published` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: fuel_logs
#

DROP TABLE IF EXISTS `fuel_logs`;

CREATE TABLE `fuel_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('1', '2016-02-13 12:59:08', '1', 'Successful login by \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('2', '2016-02-13 12:59:42', '1', 'Password reset from CMS for \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('3', '2016-02-13 13:04:33', '1', 'Pages item <em>kartice/korisnici</em> created', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('4', '2016-02-13 13:05:51', '0', 'Failed login by \'admin\' from 77.77.213.14, login attempts:   1', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('5', '2016-02-13 13:05:59', '1', 'Successful login by \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('6', '2016-02-20 08:44:54', '0', 'Failed login by \'admin\' from 77.77.213.14, login attempts:   1', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('7', '2016-02-20 08:45:04', '0', 'Failed login by \'admin\' from 77.77.213.14, login attempts:   2', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('8', '2016-02-20 08:45:10', '1', 'Successful login by \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('9', '2016-02-20 11:21:23', '1', 'Successful login by \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('10', '2016-02-20 11:22:28', '1', 'Site Variables item <em>variabla 1</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('11', '2016-02-20 11:22:50', '1', 'Blocks item <em>Toni Galic USA</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('12', '2016-02-20 12:39:24', '1', 'Authors item <em>Prvi autor</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('13', '2016-02-20 13:10:42', '1', 'Rfid item <em>CM Bodovi</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('14', '2016-02-20 13:17:05', '1', 'Rfid item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('15', '2016-02-20 13:31:53', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('16', '2016-02-20 13:33:30', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('17', '2016-02-20 13:34:35', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('18', '2016-02-20 13:35:32', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('19', '2016-02-20 13:38:19', '1', 'RFID Tags item <em>Druga kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('20', '2016-02-20 13:45:33', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('21', '2016-02-20 13:45:58', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('22', '2016-02-20 13:48:27', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('23', '2016-02-20 13:48:44', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('24', '2016-02-20 13:48:51', '1', 'RFID Tags item <em>Druga kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('25', '2016-02-20 13:49:55', '1', 'Pages item <em>kartice/korisnici</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('26', '2016-02-20 13:49:58', '1', 'Pages item <em>kartice/korisnici</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('27', '2016-02-20 13:51:01', '1', 'RFID Tags item <em>Prva kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('28', '2016-02-20 13:51:09', '1', 'RFID Tags item <em>Druga kartica</em> edited', 'info');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('29', '2016-02-20 13:52:39', '1', 'Successful login by \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('30', '2016-02-20 14:38:04', '1', 'Successful login by \'admin\' from 77.77.213.14', 'debug');
INSERT INTO `fuel_logs` (`id`, `entry_date`, `user_id`, `message`, `type`) VALUES ('31', '2016-02-20 15:05:39', '1', 'Permissions item <em>backup</em> edited', 'info');


#
# TABLE STRUCTURE FOR: fuel_navigation
#

DROP TABLE IF EXISTS `fuel_navigation`;

CREATE TABLE `fuel_navigation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The part of the path after the domain name that you want the link to go to (e.g. comany/about_us)',
  `group_id` int(5) unsigned NOT NULL DEFAULT '1',
  `nav_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The nav key is a friendly ID that you can use for setting the selected state. If left blank, a default value will be set for you.',
  `label` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The name you want to appear in the menu',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Used for creating menu hierarchies. No value means it is a root level menu item',
  `precedence` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The higher the number, the greater the precedence and farther up the list the navigational element will appear',
  `attributes` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Extra attributes that can be used for navigation implementation',
  `selected` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The pattern to match for the active state. Most likely you leave this field blank',
  `hidden` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no' COMMENT 'A hidden value can be used in rendering the menu. In some areas, the menu item may not want to be displayed',
  `language` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'english',
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes' COMMENT 'Determines whether the item is displayed or not',
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id_nav_key_language` (`group_id`,`nav_key`,`language`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_navigation` (`id`, `location`, `group_id`, `nav_key`, `label`, `parent_id`, `precedence`, `attributes`, `selected`, `hidden`, `language`, `published`) VALUES ('1', 'kartice/korisnici', '1', 'kartice/korisnici', 'Korisnici', '0', '0', '', '', 'no', 'english', 'yes');


#
# TABLE STRUCTURE FOR: fuel_navigation_groups
#

DROP TABLE IF EXISTS `fuel_navigation_groups`;

CREATE TABLE `fuel_navigation_groups` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_navigation_groups` (`id`, `name`, `published`) VALUES ('1', 'main', 'yes');


#
# TABLE STRUCTURE FOR: fuel_page_variables
#

DROP TABLE IF EXISTS `fuel_page_variables`;

CREATE TABLE `fuel_page_variables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `scope` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('string','int','boolean','array') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'string',
  `language` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'english',
  `active` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id` (`page_id`,`name`,`language`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_page_variables` (`id`, `page_id`, `name`, `scope`, `value`, `type`, `language`, `active`) VALUES ('1', '1', 'page_title', '', 'Korisnici', 'string', 'english', 'yes');
INSERT INTO `fuel_page_variables` (`id`, `page_id`, `name`, `scope`, `value`, `type`, `language`, `active`) VALUES ('2', '1', 'meta_description', '', '', 'string', 'english', 'yes');
INSERT INTO `fuel_page_variables` (`id`, `page_id`, `name`, `scope`, `value`, `type`, `language`, `active`) VALUES ('3', '1', 'meta_keywords', '', '', 'string', 'english', 'yes');
INSERT INTO `fuel_page_variables` (`id`, `page_id`, `name`, `scope`, `value`, `type`, `language`, `active`) VALUES ('4', '1', 'heading', '', 'Uvod...', 'string', 'english', 'yes');
INSERT INTO `fuel_page_variables` (`id`, `page_id`, `name`, `scope`, `value`, `type`, `language`, `active`) VALUES ('5', '1', 'body', '', 'Ostatak teksta', 'string', 'english', 'yes');
INSERT INTO `fuel_page_variables` (`id`, `page_id`, `name`, `scope`, `value`, `type`, `language`, `active`) VALUES ('6', '1', 'body_class', '', '', 'string', 'english', 'yes');


#
# TABLE STRUCTURE FOR: fuel_pages
#

DROP TABLE IF EXISTS `fuel_pages`;

CREATE TABLE `fuel_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Add the part of the url after the root of your site (usually after the domain name). For the homepage, just put the word ''home''',
  `layout` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The name of the template to associate with this page',
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes' COMMENT 'A ''yes'' value will display the page and an ''no'' value will give a 404 error message',
  `cache` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes' COMMENT 'Cache controls whether the page will pull from the database or from a saved file which is more effeicent. If a page has content that is dynamic, it''s best to set cache to ''no''',
  `date_added` datetime DEFAULT NULL,
  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `location` (`location`),
  KEY `layout` (`layout`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_pages` (`id`, `location`, `layout`, `published`, `cache`, `date_added`, `last_modified`, `last_modified_by`) VALUES ('1', 'kartice/korisnici', 'main', 'yes', 'yes', '2016-02-13 13:04:33', '2016-02-20 13:49:58', '1');


#
# TABLE STRUCTURE FOR: fuel_permissions
#

DROP TABLE IF EXISTS `fuel_permissions`;

CREATE TABLE `fuel_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'In most cases, this should be the name of the module (e.g. news)',
  `active` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('1', 'Pages', 'pages', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('2', 'Pages: Create', 'pages/create', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('3', 'Pages: Edit', 'pages/edit', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('4', 'Pages: Publish', 'pages/publish', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('5', 'Pages: Delete', 'pages/delete', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('6', 'Blocks', 'blocks', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('7', 'Blocks: Create', 'blocks/create', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('8', 'Blocks: Edit', 'blocks/edit', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('9', 'Blocks: Publish', 'blocks/publish', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('10', 'Blocks: Delete', 'blocks/delete', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('11', 'Navigation', 'navigation', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('12', 'Navigation: Create', 'navigation/create', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('13', 'Navigation: Edit', 'navigation/edit', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('14', 'Navigation: Publish', 'navigation/publish', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('15', 'Navigation: Delete', 'navigation/delete', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('16', 'Categories', 'categories', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('17', 'Categories: Create', 'categories/create', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('18', 'Categories: Edit', 'categories/edit', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('19', 'Categories: Publish', 'categories/publish', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('20', 'Categories: Delete', 'categories/delete', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('21', 'Tags', 'tags', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('22', 'Tags: Create', 'tags/create', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('23', 'Tags: Edit', 'tags/edit', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('24', 'Tags: Publish', 'tags/publish', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('25', 'Tags: Delete', 'tags/delete', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('26', 'Site Variables', 'sitevariables', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('27', 'Assets', 'assets', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('28', 'Site Documentation', 'site_docs', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('29', 'Users', 'users', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('30', 'Permissions', 'permissions', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('31', 'Manage', 'manage', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('32', 'Cache', 'manage/cache', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('33', 'Logs', 'logs', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('34', 'Settings', 'settings', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('35', 'Generate Code', 'generate', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('36', 'backup', 'backup', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('37', 'Backup: Create', 'backup/create', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('38', 'Backup: Edit', 'backup/edit', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('39', 'Backup: Publish', 'backup/publish', 'yes');
INSERT INTO `fuel_permissions` (`id`, `description`, `name`, `active`) VALUES ('40', 'Backup: Delete', 'backup/delete', 'yes');


#
# TABLE STRUCTURE FOR: fuel_relationships
#

DROP TABLE IF EXISTS `fuel_relationships`;

CREATE TABLE `fuel_relationships` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `candidate_table` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `candidate_key` int(11) NOT NULL,
  `foreign_table` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_table` (`candidate_table`,`candidate_key`),
  KEY `foreign_table` (`foreign_table`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: fuel_settings
#

DROP TABLE IF EXISTS `fuel_settings`;

CREATE TABLE `fuel_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `key` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module` (`module`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: fuel_site_variables
#

DROP TABLE IF EXISTS `fuel_site_variables`;

CREATE TABLE `fuel_site_variables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `scope` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'leave blank if you want the variable to be available to all pages',
  `active` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_site_variables` (`id`, `name`, `value`, `scope`, `active`) VALUES ('1', 'variabla 1', '', '', 'yes');


#
# TABLE STRUCTURE FOR: fuel_tags
#

DROP TABLE IF EXISTS `fuel_tags`;

CREATE TABLE `fuel_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'english',
  `precedence` int(11) NOT NULL,
  `published` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: fuel_users
#

DROP TABLE IF EXISTS `fuel_users`;

CREATE TABLE `fuel_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `reset_key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `super_admin` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `active` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `fuel_users` (`id`, `user_name`, `password`, `email`, `first_name`, `last_name`, `language`, `reset_key`, `salt`, `super_admin`, `active`) VALUES ('1', 'admin', 'c546e0ccf0ceeeb87077d5ba58025c32e07ca7f9', 'marko@reflect.ba', 'Marko', 'Solomun', 'english', '', 'df22e3172536cf96452b9884c457d6d8', 'yes', 'yes');


#
# TABLE STRUCTURE FOR: rfid_tags
#

DROP TABLE IF EXISTS `rfid_tags`;

CREATE TABLE `rfid_tags` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dev_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mac` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `enabled` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `rfid_tags` (`id`, `name`, `dev_id`, `tag`, `mac`, `description`, `enabled`) VALUES ('1', 'Prva kartica', 'DFTK35', 'A93280', '0F:0F:0F:0D', 'Opis gdje se nalazi kartica...', 'yes');
INSERT INTO `rfid_tags` (`id`, `name`, `dev_id`, `tag`, `mac`, `description`, `enabled`) VALUES ('2', 'Druga kartica', 'DFTK35', '454C1B0', '0F:0F:0F:0D', 'Vlasnik druge kartice..', 'yes');


