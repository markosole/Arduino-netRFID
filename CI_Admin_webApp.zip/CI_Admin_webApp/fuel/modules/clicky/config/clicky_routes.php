<?php 
$route[FUEL_FOLDER.'/clicky/dashboard'] = CLICKY_FOLDER.'/dashboard';
$route[FUEL_FOLDER.'/clicky'] = CLICKY_FOLDER;

