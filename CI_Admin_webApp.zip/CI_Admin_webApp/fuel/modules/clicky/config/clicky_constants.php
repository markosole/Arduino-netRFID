<?php 
define('CLICKY_VERSION', '0.1');
define('CLICKY_FOLDER', 'clicky');
define('CLICKY_PATH', APPPATH.MODULES_FOLDER.'/'.CLICKY_FOLDER.'/');