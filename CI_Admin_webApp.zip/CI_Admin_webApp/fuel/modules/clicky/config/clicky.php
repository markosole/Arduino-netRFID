<?php 
$config['clicky'] = array();
$config['clicky']['url'] = 'http://getclicky.com/user/login';
$config['clicky']['login'] = '';
$config['clicky']['pwd'] = '';
$config['clicky']['api'] = '';
$config['clicky']['permission'] = 'clicky';