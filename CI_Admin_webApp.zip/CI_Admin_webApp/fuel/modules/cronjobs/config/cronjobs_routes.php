<?php 
$route[FUEL_ROUTE.'tools/cronjobs'] = 'cronjobs';