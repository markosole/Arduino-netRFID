<?php 
define('CRONJOBS_VERSION', '1.0');
define('CRONJOBS_FOLDER', 'cronjobs');
define('CRONJOBS_PATH', MODULES_PATH.CRONJOBS_FOLDER.'/');