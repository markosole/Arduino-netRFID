MAILTO=
# change the path to your CI bootstrap index.php file below
0 12 * * * /var/www/httpdocs/index.php backup/cron