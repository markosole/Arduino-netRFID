<?php 
$route[FUEL_FOLDER.'/tools/campaign_monitor'] = 'campaign_monitor';