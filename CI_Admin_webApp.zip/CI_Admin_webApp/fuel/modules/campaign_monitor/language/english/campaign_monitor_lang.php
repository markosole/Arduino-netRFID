<?php 
$lang['campain_monitor_intro'] = 'Below are summary statistics for your most recent %1s <a href="http://%2s.createsend.com/reports">Campaign Moniter</a> campaigns.';
$lang['campaign_monitor_recipients'] = 'Recipients';
$lang['campaign_monitor_total_opened'] = 'Total Opened';
$lang['campaign_monitor_clicks'] = 'Clicks';
$lang['campaign_monitor_unsubscribed'] = 'Unsubscribed';
$lang['campaign_monitor_bounced'] = 'Bounced';
$lang['campaign_monitor_unique_opens'] = 'Unique Opens';
$lang['campaign_monitor_no_data'] = 'There is currently no campaign data associated with the client %1s.';