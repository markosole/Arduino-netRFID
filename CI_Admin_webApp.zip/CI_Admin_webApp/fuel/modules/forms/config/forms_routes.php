<?php 

$route[FUEL_ROUTE.'forms'] = FUEL_FOLDER.'/module';
$route[FUEL_ROUTE.'forms/(.*)'] = FUEL_FOLDER.'/module/$1';

$route[FUEL_ROUTE.'form_entries'] = FUEL_FOLDER.'/module';
$route[FUEL_ROUTE.'form_entries/(.*)'] = FUEL_FOLDER.'/module/$1';