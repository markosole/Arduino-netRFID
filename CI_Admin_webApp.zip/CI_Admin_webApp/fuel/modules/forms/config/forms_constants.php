<?php 
define('FORMS_VERSION', '0.9');
define('FORMS_FOLDER', 'forms');
define('FORMS_PATH', MODULES_PATH.FORMS_FOLDER.'/');