<?php 
define('BACKUP_VERSION', '1.0');
define('BACKUP_FOLDER', 'backup');
define('BACKUP_PATH', MODULES_PATH.BACKUP_FOLDER.'/');