<?php 
$route[FUEL_ROUTE.'tools/backup'] = 'backup';
$route[FUEL_ROUTE.'backup/dashboard'] = 'backup/dashboard';
