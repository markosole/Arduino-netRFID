<?php 
// to simplify updates, we post the core libraries in the fuel module
require_once(FUEL_PATH.'core/MY_DB_mysql_result.php');