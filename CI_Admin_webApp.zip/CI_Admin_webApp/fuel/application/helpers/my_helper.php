<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
// add your site specific functions here

/* End of file my_helper.php */
/* Location: ./application/helpers/my_helper.php */
