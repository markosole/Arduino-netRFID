<?php header('Content-Type: text/plain'); ?>
<?=fuel_var('body')?>